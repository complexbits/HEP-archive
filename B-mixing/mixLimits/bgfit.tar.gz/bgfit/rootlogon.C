{

gSystem->Load("$HOME/lib/libRooFitCore.so");
gSystem->Load("$HOME/lib/libRooFitModels.so");


  //  gSystem->Load("libRooFitCore.so");
  // gSystem->Load("libRooFitModels.so");

  //gSystem->Load("./RooComplex/libroomath.a");

gROOT->SetStyle("Plain");
}
